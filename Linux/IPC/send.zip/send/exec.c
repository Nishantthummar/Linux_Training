#include <stdio.h>

int main() {
	printf("\nPrinting from exec.c");
}
